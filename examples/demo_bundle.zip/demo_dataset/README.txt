演示数据集（Genome Gene Explorer）

本包用于试用「文件 → 导入压缩包（自动识别文件）」。

  assembly_v1.fna      基因组序列（FASTA，3 条序列，约 21 kb）
  annotation.gff3      基因注释（GFF3，11 个基因，含正负链 / 多转录本 / 边界情况）
  sequences_a.fna      参考 mRNA（故意没有写 mrna，靠内容识别）
  sequences_b.fna      参考 CDS（故意没有写 cds，靠长度与注释比对识别）
  peptides.faa         参考蛋白

导入后程序会列出每个文件被判定成什么、依据是什么，确认无误再点「开始导入」。
数据来自 examples/make_example_data.py 的确定性合成数据，可安全用于演示。
